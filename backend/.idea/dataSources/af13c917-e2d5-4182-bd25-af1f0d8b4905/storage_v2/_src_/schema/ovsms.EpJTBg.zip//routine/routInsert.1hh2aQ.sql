create
    definer = root@localhost procedure routInsert(IN cLineID int, IN cName varchar(255), IN cSequence int)
begin
    if exists(select * from traffic_control_stop where stopName  = cName and line_id = cLineID) then
        select 'stop exists';
    else
        update traffic_control_stop set sequence = sequence+1 where sequence >= cSequence;
        insert into traffic_control_stop values (cName,cSequence,cLineID);
        select 'insert successfully';
    end if;
end;


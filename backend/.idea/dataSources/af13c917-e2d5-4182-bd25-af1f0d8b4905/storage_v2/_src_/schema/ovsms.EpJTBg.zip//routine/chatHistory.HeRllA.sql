create
    definer = root@localhost procedure chatHistory(IN cusID int, IN servId int)
begin
    select * from information_management_chat where customer_id = cusID and servicer_id = servId order by information_management_chat.time asc ;
end;


create
    definer = root@localhost procedure regist(IN id int, IN cName varchar(64), IN cPassword varchar(64),
                                              IN cAge int unsigned)
begin
    if exists(select * from man_management_customer where name = cName) then
        select 'This name has been taken';
    else
        insert into man_management_customer values (id,cName,cPassword,cAge,null);
    end if;
end;


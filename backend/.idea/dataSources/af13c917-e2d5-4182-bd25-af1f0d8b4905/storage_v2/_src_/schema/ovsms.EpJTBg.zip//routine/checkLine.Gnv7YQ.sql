create
    definer = root@localhost procedure checkLine(IN cLineID int)
begin
    if not exists(select * from traffic_control_stop where line_id = cLineID) then
        select 'line not exists';
    else
        select stopName,sequence from traffic_control_stop order by sequence asc;
    end if;
end;

